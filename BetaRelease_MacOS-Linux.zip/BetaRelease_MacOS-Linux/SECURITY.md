## ⚠️ **SECURITY POLICY:**
- If you discover a vulnerability in this tool, please report it responsibly.

## ⚠️ **FOR REPORTING AN ISSUE/BUG:**
- Please report at: vu0ng.tr4nduc@gmail.com

## ⚠️ **DISCLOSURE:**
- Please include as much detail as possible about the current issue (i.e command used, file involved, error logs, etc.). 
I'll acknowledge and fix them as soon as possible. Thank you!

- Current tool version: Beta Release v1.0.0

