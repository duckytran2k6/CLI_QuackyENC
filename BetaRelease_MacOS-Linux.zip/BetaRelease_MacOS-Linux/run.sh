#!/bin/bash
exec java -jar duckytool.jar "$@"