# **Welcome to DuckyTool 🦆,**

📥 This is an open-source basic CLI-based text file encryption tool where you can encrypt and decrypt right on your 
local Laptop/PC! Currently, this is a Beta test version for the tool which the main priority is to test the functionality
and compatability of the tool on different OS from Window to Mac and even Linux! In the near future, the tool will be 
developed into a desktop app with more features!

## ✅ **Features:**
- Password-based file encryption.
- Key pair-based hybrid encryption.
- Secure zip file with auto download + temp files clean up.
- Supports multiple files encryption.
- CLI with file select GUI (auto pop-up).

## ❓ **For more info:** 
Please refer to INSTRUCTION and SECURITY files.