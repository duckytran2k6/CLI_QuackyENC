## ⚠️ **SECURITY POLICY:**
- If you discover a vulnerability in this tool, please report it responsibly.

## ⚠️ **FOR REPORTING A VULNERABILITY OR AN ISSUE/BUG:**
- Please email me at: duckytool-crypto@gmail.com
- Include as much detail as possible about the current issue (i.e command used, file involved, error logs, etc.)

## ⚠️ **DISCLOSURE:**
- For sensitive bugs, please report it privately and do not open public issues. I'll acknowledge and fix them as soon as possible!

- Current tool version: Beta Release v1.0.0

